
untangle
--------
.. image:: https://secure.travis-ci.org/stchris/untangle.png?branch=master

untangle parses an XML document and returns a Python object which makes it
easy to access the data you want.

Example:

::

    import untangle
    obj = untangle.parse('<root><child name="child1"/></root>')
    assert obj.root.child['name'] == u'child1'

See http://0chris.com/untangle and
    http://readthedocs.org/docs/untangle/en/latest/


